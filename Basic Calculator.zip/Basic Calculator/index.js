let inputField=document.getElementById('inputField');
let buttons=document.querySelectorAll('#input');
let equalsBtn=document.getElementById('equalsBtn');
let cancelBtn=document.getElementById('cancelBtn');
let backspaceBtn=document.getElementById('backspaceBtn');
buttons.forEach(button=>{
    button.addEventListener('click',()=>{
        if(button.innerHTML=='x')
            inputField.value+='*';
        else
            inputField.value+=button.innerHTML;
    });
});
cancelBtn.addEventListener('click',()=>{
    inputField.value="";
});
backspaceBtn.addEventListener('click',()=>{
    inputField.value=inputField.value.slice(0,-1);
});
equalsBtn.addEventListener('click',()=>{
    try{
        let result=eval(inputField.value);
        inputField.value=result;
    }
    catch{
        alert('Invalid Expression');
        inputField.value="";
    }
});