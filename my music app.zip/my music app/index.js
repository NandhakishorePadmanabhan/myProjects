let progress=document.getElementById('progress');
let ctrlIcon=document.getElementById('ctrlIcon');
let song=document.getElementById('song');
let bars=document.getElementById('bars');
let songList=document.getElementById('songList');
let volumeBtn=document.getElementById('volume-btn');
const playlist = [
    {
        source: 'media/In_the_name_of_love.mp3',
        title: 'In the name of love',
        artist: 'Bebe rexha ft.Martin garrix',
        picture: 'media/In_the_name_of_love.jpg'
    },
    {
        source: 'media/Love_me_like_you_do.mp3',
        title: 'Love me like you do',
        artist: 'Ellie goulding',
        picture: 'media/Love_me_like_you_do.jpg'
    },
    {
        source: 'media/My_heart_will_go_on.mp3',
        title: 'My heart will go on',
        artist: 'Celine dion',
        picture: 'media/My_heart_will_go_on.jpg'
    }
];
let currentSongIndex = 0;
song.onloadedmetadata=function(){
    progress.max=song.duration;
    progress.value=song.currentTime;
}
function playPause(){
    if(ctrlIcon.classList.contains("fa-pause")){
        song.pause();
        ctrlIcon.classList.remove("fa-pause");
        ctrlIcon.classList.add("fa-play");
    }
    else{
        song.play();
        ctrlIcon.classList.remove("fa-play");
        ctrlIcon.classList.add("fa-pause");
    }
}
if(song.play()){
    setInterval(()=>{
        progress.value=song.currentTime;
    },500);
}
progress.onchange=function(){
    song.currentTime=progress.value;
}
function loadSong(source,title,artist,picture,index){
    document.querySelector('source').src=source;
    document.querySelector('.song-img').src=picture;
    document.querySelector('.song-img').alt=title;
    document.querySelector('h1').innerHTML=title;
    document.querySelector('p').innerHTML=artist;
    song.load();
    song.play();
    ctrlIcon.classList.remove('fa-play');
    ctrlIcon.classList.add('fa-pause');
    currentSongIndex=index;
}
bars.addEventListener('click',()=>{
    songList.classList.toggle('show');
})
function loadSongByIndex(currentSongIndex){
    let songData=playlist[currentSongIndex];
    document.querySelector('source').src=songData.source;
    document.querySelector('.song-img').src=songData.picture;
    document.querySelector('.song-img').alt=songData.title;
    document.querySelector('h1').innerHTML=songData.title;
    document.querySelector('p').innerHTML=songData.artist;
    ctrlIcon.classList.remove("fa-play");
    ctrlIcon.classList.add("fa-pause");
    song.load();
    song.play();
}
function nextSong(){
    currentSongIndex=(currentSongIndex+1)%playlist.length;
    loadSongByIndex(currentSongIndex);
}
function previousSong(){
    if(currentSongIndex==0){
        currentSongIndex=playlist.length-1;
    }
    else{
        currentSongIndex--;
    }
    loadSongByIndex(currentSongIndex);
}
song.addEventListener('ended',nextSong);
function muteUnmute(){
    if(volumeBtn.classList.contains('fa-volume-up')){
        song.muted=true;
        volumeBtn.classList.remove('fa-volume-up');
        volumeBtn.classList.add('fa-volume-mute');
    }
    else{
        song.muted=false;
        volumeBtn.classList.remove('fa-volume-mute');
        volumeBtn.classList.add('fa-volume-up');
    }
}